from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument, IncludeLaunchDescription, RegisterEventHandler,
    SetEnvironmentVariable, TimerAction
)
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from moveit_configs_utils import MoveItConfigsBuilder
import os

def generate_launch_description():
    ld = LaunchDescription()

    # --- share dirs ---
    uryt_share     = get_package_share_directory("robotic_arms_control")
    moveit_cfg_pkg     = get_package_share_directory("moveit_config_pkg")
    robotiq_share  = get_package_share_directory("robotic_arms_control")
    # ur_share       = get_package_share_directory("ur_description")
    gazebo_ros_dir = get_package_share_directory("gazebo_ros")
    world_file = os.path.join(moveit_cfg_pkg, 'world', 'world.world')

    # --- ENV Gazebo ---
    ld.add_action(SetEnvironmentVariable(
        name="GAZEBO_MODEL_PATH",
        value=":".join(["/usr/share/gazebo-11/models", "/home/adithya-si3510/arm_ws/src/", "/home/adithya-si3510/arm_ws/src/moveit_config_pkg/models"])
    ))
    # ld.add_action(SetEnvironmentVariable(
    #     name="GAZEBO_MODEL_PATH",
    #     value=":".join([
    #         os.path.join(uryt_share,"models"),
    #         os.path.join(robotiq_share,"models"),
    #         os.path.expanduser("~/.gazebo/models")
    #     ])
    # ))
    # ld.add_action(SetEnvironmentVariable(
    #     name="GAZEBO_PLUGIN_PATH",
    #     value=":".join([
    #         "/opt/ros/humble/lib",
    #         os.path.normpath(os.path.join(uryt_share, "..", "..", "lib")),
    #     ])
    # ))

    # --- args ---
    with_rviz     = DeclareLaunchArgument("with_rviz", default_value="true")
    with_octomap  = DeclareLaunchArgument("with_octomap", default_value="true")  # << NEW
    x_arg = DeclareLaunchArgument("x", default_value="0.0")
    y_arg = DeclareLaunchArgument("y", default_value="0")
    z_arg = DeclareLaunchArgument("z", default_value="0.0")
    ld.add_action(with_rviz); ld.add_action(with_octomap)
    ld.add_action(x_arg); ld.add_action(y_arg); ld.add_action(z_arg)

    # --- MoveIt config ---
    joint_controllers_file = os.path.join(moveit_cfg_pkg, "config", "ur5_controllers_gripper.yaml")
    moveit_config = (
        MoveItConfigsBuilder("custom_robot", package_name="moveit_config_pkg")
        .robot_description(
            file_path="config/panda.urdf.xacro",
            mappings={
                "initial_positions_file": os.path.join(moveit_cfg_pkg, "config", "initial_positions.yaml"),
            },
        )
        .robot_description_semantic(file_path="config/panda.srdf")
        .trajectory_execution(file_path="config/moveit_controllers.yaml")
        .robot_description_kinematics(file_path="config/kinematics.yaml")
        .planning_pipelines(pipelines=["ompl", "chomp", "pilz_industrial_motion_planner"])
        .planning_scene_monitor(
            publish_robot_description=True,
            publish_robot_description_semantic=True,
            publish_planning_scene=True
        )
        .to_moveit_configs()
    )

    # --- Gazebo ---
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_ros_dir, "launch", "gazebo.launch.py")),
        launch_arguments={"use_sim_time":"true", "gui":"true", "paused":"false", "world": world_file}.items() #, "world": world_file
    )
    ld.add_action(gazebo)

    # --- RSP ---
    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[moveit_config.robot_description, {"use_sim_time": True}],
        output="screen",
    )
    ld.add_action(robot_state_publisher)

    # --- Spawn ---
    spawn = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=[
            "-entity","cobot",
            "-topic","robot_description",
            "-x", LaunchConfiguration("x"),
            "-y", LaunchConfiguration("y"),
            "-z", LaunchConfiguration("z"),
        ],
        output="screen",
    )
    ld.add_action(TimerAction(period=3.0, actions=[spawn]))
    # controllers_file = os.path.join(
    #     moveit_cfg_pkg,
    #     "config",
    #     "ros2_controllers.yaml"   # Change this if your file has a different name
    # )

    # controller_manager = Node(
    #     package="controller_manager",
    #     executable="ros2_control_node",
    #     parameters=[
    #         moveit_config.robot_description,
    #         # controllers_file,
    #         {"use_sim_time": True},
    #     ],
    #     output="screen",
    # )

    # ld.add_action(controller_manager)
    jsb  = Node(package="controller_manager", executable="spawner",
                arguments=["joint_state_broadcaster"], output="screen")
    arm  = Node(package="controller_manager", executable="spawner",
                arguments=["arm_controller"], output="screen")
    grip = Node(package="controller_manager", executable="spawner",
                arguments=["gripper_controller"], output="screen")
    # ld.add_action(jsb)
    # ld.add_action(arm)
    # ld.add_action(grip)

    ld.add_action(RegisterEventHandler(
        OnProcessStart(target_action=spawn, on_start=[
            TimerAction(period=2.0, actions=[jsb]),
            TimerAction(period=3.0, actions=[arm, grip]),
        ])
    ))
    use_sim_time={"use_sim_time": True}
    config_dict = moveit_config.to_dict()
    config_dict.update(use_sim_time)
    
    static_tf_world_to_realsense = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='world_to_camera_tf',
        arguments=[
            '--x', '0.0',
            '--y', '0.0',
            '--z', '2.5',
            '--roll', '0.0',
            '--pitch', '1.5708',  # 90 deg pitch DOWN
            '--yaw', '0.0',
            '--frame-id', 'world',
            '--child-frame-id', 'realsense_link'
        ]
    )

    # 2. Camera Optical Alignment: realsense_link -> camera_depth_optical_frame
    # Transforms standard robot coordinates (X-fwd/Z-up) to optical convention (Z-fwd/Y-down)
    static_tf_realsense_to_optical = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='camera_to_optical_tf',
        arguments=[
            '--x', '0.0',
            '--y', '0.0',
            '--z', '0.0',
            '--roll', '-1.5708',
            '--pitch', '0.0',
            '--yaw', '-1.5708',
            '--frame-id', 'realsense_link',
            '--child-frame-id', 'camera_depth_optical_frame'
        ]
    )

    move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[config_dict],
        arguments=["--ros-args", "--log-level", "info"],
    )


    rviz_cfg = os.path.join(moveit_cfg_pkg,
                            "config", "moveit.rviz")
    rviz = Node(
        package="rviz2", executable="rviz2", name="rviz2", output="screen",
        arguments=["-d", rviz_cfg],
        parameters=[
            moveit_config.robot_description,
            moveit_config.robot_description_semantic,
            moveit_config.planning_pipelines,
            moveit_config.robot_description_kinematics,
            {"use_sim_time": True},
        ],
        condition=IfCondition(LaunchConfiguration("with_rviz"))
    )
    ld.add_action(static_tf_world_to_realsense)
    ld.add_action(static_tf_realsense_to_optical)
    ld.add_action(rviz)

    mg_params = moveit_config.to_dict()
    mg_params.update({"use_sim_time": True})

    move_group_with_octomap = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[mg_params],
        arguments=["--ros-args","--log-level","info"],
        condition=IfCondition(LaunchConfiguration("with_octomap")),   # << NEW
    )

    mg_params_no_sensors = dict(mg_params)
    mg_params_no_sensors.pop("sensors", None)

    move_group_no_octomap = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[mg_params_no_sensors],
        arguments=["--ros-args","--log-level","info"],
        condition=UnlessCondition(LaunchConfiguration("with_octomap")),
    )

    
    ld.add_action(move_group_node)
    # ld.add_action(move_group_with_octomap)
    # ld.add_action(move_group_no_octomap)
    pick_and_pplace_server = Node(
        package="moveit_config_pkg",
        executable="pick_and_place_node",
        output="screen"
    )
    ld.add_action(pick_and_pplace_server)

    chessboardscan = Node(
        package="moveit_config_pkg",
        executable="testmodel.py",
        output="screen"
    )
    chesspicespawn = Node(
        package="moveit_config_pkg",
        executable="pice_spawn.py",
        output="screen"
    )
    ld.add_action(chessboardscan)
    ld.add_action(chesspicespawn)
    chess_engine = Node(
        package="moveit_config_pkg",
        executable="chess_managment.py",
        output="screen"
    )
    # ld.add_action(chess_engine)
    return ld